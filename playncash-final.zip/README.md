# Casual Games + Coins + Ads + Redeem — COMPLETE Build

This package extends the skeleton with:
- Phone OTP Auth (Firebase Phone)
- Secure server-side game rewards:
  - `playDice` (server RNG + throttle)
  - `awardQuiz` (daily cap)
  - `awardMemory` (daily cap)
- Leaderboards (daily + monthly) auto-updated on credits
- Referral system (referrer rewarded when referee hits 50 coins milestone)
- FCM payout notifications (on approve/reject)
- Admin web shows Pending Withdraws + Daily Leaderboard

> Payouts remain **manual** via admin console (no Cashfree API).

## Setup (short)
1) Firebase project: enable Auth (Email + Phone), Firestore, Functions, Storage, Remote Config, Cloud Messaging.
2) Put Web App config into `.env` (see `.env.example`).
3) Set custom claim `admin: true` for your admin user (use Admin SDK or CLI).
4) Deploy:
```bash
npm install
firebase login
firebase use <project-id>
cd functions && npm run build && firebase deploy --only functions && cd ..
```
5) Run mobile app:
```bash
cd apps/mobile
npm run start
```
6) Run admin web:
```bash
cd apps/admin
npm run dev
```

### Remote Config Keys (recommended defaults)
- `bonus_min` = 3
- `bonus_max` = 5
- `quiz_daily_cap` = 10
- `memory_daily_cap` = 10
- `min_withdraw` = 20

