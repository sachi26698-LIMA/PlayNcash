import { initializeApp, getApps } from 'firebase/app';
import { getAuth, signInWithEmailAndPassword, onAuthStateChanged } from 'firebase/auth';
import { getFunctions, httpsCallable } from 'firebase/functions';
import { getFirestore, collection, query, where, onSnapshot, orderBy, getDocs, limit } from 'firebase/firestore';

const cfg = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY || (window as any).FIREBASE_API_KEY,
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN,
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID,
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID,
  appId: import.meta.env.VITE_FIREBASE_APP_ID
};

if (!getApps().length) initializeApp(cfg);

export const auth = getAuth();
export const db = getFirestore();
export const functions = getFunctions();

export const api = {
  signIn: (email: string, password: string) => signInWithEmailAndPassword(auth, email, password),
  onAuth: (cb: any) => onAuthStateChanged(auth, cb),
  listenPendingWithdraws: (cb: any) => {
    const q = query(collection(db, 'withdrawRequests'), where('status','==','pending'), orderBy('createdAt','desc'));
    return onSnapshot(q, cb);
  },
  markPaid: async (id: string) => httpsCallable(functions, 'markWithdrawPaid')({ id }),
  reject: async (id: string, reason: string) => httpsCallable(functions, 'markWithdrawRejected')({ id, reason }),
};
