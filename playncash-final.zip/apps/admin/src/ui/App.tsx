import React, { useEffect, useState } from 'react';
import { api, db } from '../firebase';
import { collection, query, orderBy, onSnapshot, limit, getDocs } from 'firebase/firestore';

export default function App() {
  const [user, setUser] = useState<any>(null);
  useEffect(() => api.onAuth(setUser), []);
  if (!user) return <Login />;
  return <Dashboard />;
}

function Login() {
  const [email, setEmail] = useState('admin@example.com');
  const [password, setPassword] = useState('adminpass');
  const [err, setErr] = useState<string | null>(null);
  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErr(null);
    try { await api.signIn(email, password); }
    catch (e: any) { setErr(e.message); }
  };
  return (
    <div style={{ maxWidth: 360, margin: '80px auto', fontFamily: 'Inter, system-ui, sans-serif' }}>
      <h2>Admin Login</h2>
      <form onSubmit={submit}>
        <input value={email} onChange={e=>setEmail(e.target.value)} placeholder="Email" style={iStyle} />
        <input value={password} onChange={e=>setPassword(e.target.value)} placeholder="Password" type="password" style={iStyle} />
        <button style={bStyle}>Sign in</button>
        {err && <p style={{ color: 'crimson' }}>{err}</p>}
      </form>
    </div>
  );
}

function Dashboard() {
  const [rows, setRows] = useState<any[]>([]);
  const [leaders, setLeaders] = useState<any[]>([]);

  useEffect(() => api.listenPendingWithdraws((snap:any) => {
    setRows(snap.docs.map((d:any)=>({id:d.id, ...d.data()})));
  }), []);

  useEffect(() => {
    const today = new Date().toISOString().slice(0,10);
    const ref = collection(db, 'leaderboardDaily', today, 'users');
    const q = query(ref, orderBy('score','desc'), limit(20));
    return onSnapshot(q, snap => setLeaders(snap.docs.map(d=>({id:d.id, ...d.data()}))));
  }, []);

  return (
    <div style={{ padding: 24, fontFamily: 'Inter, system-ui, sans-serif' }}>
      <h2>Withdraw Requests (Pending)</h2>
      <table style={{ borderCollapse: 'collapse', width: '100%', maxWidth: 920, marginBottom: 24 }}>
        <thead>
          <tr>
            <th style={th}>ID</th><th style={th}>UID</th><th style={th}>Amount</th><th style={th}>UPI</th><th style={th}>Name</th><th style={th}>Actions</th>
          </tr>
        </thead>
        <tbody>
          {rows.map(r => (
            <tr key={r.id}>
              <td style={td}>{r.id}</td>
              <td style={td}>{r.uid}</td>
              <td style={td}>₹{r.amount}</td>
              <td style={td}>{r.upi}</td>
              <td style={td}>{r.name}</td>
              <td style={td}>
                <button onClick={() => api.markPaid(r.id)} style={bSmall}>Mark Paid</button>{' '}
                <button onClick={() => { const reason = prompt('Reason?') || 'Policy'; api.reject(r.id, reason); }} style={bSmallDanger}>Reject</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      <h2>Today's Leaders (Top 20)</h2>
      <table style={{ borderCollapse: 'collapse', width: '100%', maxWidth: 620 }}>
        <thead><tr><th style={th}>UID</th><th style={th}>Score</th></tr></thead>
        <tbody>
          {leaders.map(l => (<tr key={l.id}><td style={td}>{l.uid}</td><td style={td}>{l.score}</td></tr>))}
        </tbody>
      </table>
    </div>
  );
}

const iStyle: React.CSSProperties = { width:'100%', padding:'10px 12px', margin:'8px 0', border:'1px solid #ccc', borderRadius:10 };
const bStyle: React.CSSProperties = { padding:'10px 12px', borderRadius:10, background:'#111', color:'#fff', border:'none', width:'100%' };
const th: React.CSSProperties = { textAlign:'left', borderBottom:'1px solid #ddd', padding:8 };
const td: React.CSSProperties = { borderBottom:'1px solid #eee', padding:8, fontSize:14 };
const bSmall: React.CSSProperties = { padding:'6px 10px', borderRadius:8, border:'1px solid #0a0', background:'#efe' };
const bSmallDanger: React.CSSProperties = { padding:'6px 10px', borderRadius:8, border:'1px solid #a00', background:'#fee' };
