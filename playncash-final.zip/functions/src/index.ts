import * as admin from 'firebase-admin';
import * as functions from 'firebase-functions';
import { ensureUserWallet } from './wallet.js';
import { claimDailyBonus } from './bonus.js';
import { applyRedeemCode } from './redeem.js';
import { requestWithdraw, markWithdrawPaid, markWithdrawRejected } from './withdraw.js';
import { playDice, awardQuiz, awardMemory } from './games.js';
import { applyReferrer, onWalletCredit } from './referrals.js';

admin.initializeApp();

export const onUserCreate = functions.auth.user().onCreate(async (user) => {
  const db = admin.firestore();
  const uid = user.uid;
  const code = uid.slice(0,6).toUpperCase();
  await db.collection('users').doc(uid).set({
    uid,
    phone: user.phoneNumber || null,
    email: user.email || null,
    referralCode: code,
    createdAt: admin.firestore.FieldValue.serverTimestamp()
  }, { merge: true });
  await ensureUserWallet(uid);
});

export { claimDailyBonus, applyRedeemCode, requestWithdraw, markWithdrawPaid, markWithdrawRejected, playDice, awardQuiz, awardMemory, applyReferrer, onWalletCredit };
